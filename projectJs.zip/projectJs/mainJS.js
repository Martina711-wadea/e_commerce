var advArr=['1.jpg','2.jpg', '3.jpg']
var myadv= document.getElementsByTagName('img')[0]
var i=1;
function showAdd(){
    myadv.src="./" + advArr[i];
    if(i==advArr.length-1){
        i=-1;
    }
    i++;

}

function showData(){



}
setInterval(showAdd,1500)
//************************************** */


function goToform(){
    open('file:///E:/projectJs/regstration.html', '_blanck',"width=420,height=400, screenX=350,screenY=200" )
}




var xhr =new XMLHttpRequest();

xhr.open('GET','./data.json',false)
var res;

    xhr.onreadystatechange=function(){
        if(xhr.readyState==4 && xhr.status==200){
    
            res= JSON.parse(xhr.response)
    
             for(o in res){
                let nm=res[o].mname
                // let sup=res[o].subject
                // let time=res[o].Time
                // let prs=res[o].Price
                let mg=res[o].imgs
            
                let h1=document.createElement('h1')
                let sec=document.getElementsByTagName('section')[0]
                sec.style.backgroundColor='green'
                h1.innerText=nm
                document.body.appendChild(h1)
                 h1.style.fontSize='60px'
                 h1.style.color='red'
    
                 let myimg=document.createElement('img')
                myimg.src=mg

                myimg.addEventListener('click',function(){


                    location
                })
                document.body.appendChild(myimg)
    
                // let p1=document.createElement('p')
                // p1.innerText=sup
                // document.body.appendChild(p1)
                // p1.style.fontSize='40px'
                //  p1.style.color='beige'
    
                // let p2=document.createElement('p')
                // p2.innerText=time
                // document.body.appendChild(p2)
                //  p2.style.fontSize='40px'
                //  p2.style.color='beige'
    
                // let p3=document.createElement('p')
                // p3.innerText=prs
                // document.body.appendChild(p3) 
                //  p3.style.fontSize='40px'
                //  p3.style.color='beige'
    
                
    
    
            
            }
            
           
             
        } 
       
    }
    xhr.send()








 